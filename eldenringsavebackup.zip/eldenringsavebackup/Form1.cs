﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eldenringsavebackup
{
    public partial class ERSaveLoader : Form
    {
        public ERSaveLoader()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sourceFile1 = @"C:\Users\thoma\AppData\Roaming\EldenRing\76561198024051617\ER0000.sl2";
            string sourceFile2 = @"C:\Users\thoma\AppData\Roaming\EldenRing\76561198024051617\ER0000.sl2.bak";
            string sourceFile3 = @"C:\Users\thoma\AppData\Roaming\EldenRing\76561198024051617\steam_autocloud.vdf";
            string destinationFile1 = @"C:\Users\thoma\AppData\Roaming\EldenRing\Backup\ER0000.sl2";
            string destinationFile2 = @"C:\Users\thoma\AppData\Roaming\EldenRing\Backup\ER0000.sl2.bak";
            string destinationFile3 = @"C:\Users\thoma\AppData\Roaming\EldenRing\Backup\steam_autocloud.vdf";
            try
            {
                File.Copy(sourceFile1, destinationFile1, true);
                File.Copy(sourceFile2, destinationFile2, true);
                File.Copy(sourceFile3, destinationFile3, true);
            }
            catch (IOException iox)
            {
                Console.WriteLine(iox.Message);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string sourceFile1 = @"C:\Users\thoma\AppData\Roaming\EldenRing\Backup\ER0000.sl2";
            string sourceFile2 = @"C:\Users\thoma\AppData\Roaming\EldenRing\Backup\ER0000.sl2.bak";
            string sourceFile3 = @"C:\Users\thoma\AppData\Roaming\EldenRing\Backup\steam_autocloud.vdf";
            string destinationFile1 = @"C:\Users\thoma\AppData\Roaming\EldenRing\76561198024051617\ER0000.sl2";
            string destinationFile2 = @"C:\Users\thoma\AppData\Roaming\EldenRing\76561198024051617\ER0000.sl2.bak";
            string destinationFile3 = @"C:\Users\thoma\AppData\Roaming\EldenRing\76561198024051617\steam_autocloud.vdf";
            try
            {
                File.Copy(sourceFile1, destinationFile1, true);
                File.Copy(sourceFile2, destinationFile2, true);
                File.Copy(sourceFile3, destinationFile3, true);
            }
            catch (IOException iox)
            {
                Console.WriteLine(iox.Message);
            }
        }
    }
}
